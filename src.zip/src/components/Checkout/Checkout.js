import React from "react";
import "../../App.css";
import StepperComponent from "./../Stepper/Stepper";

function Checkout() {
  return <StepperComponent />;
}

export default Checkout;
